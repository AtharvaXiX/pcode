<?php 
	echo ("Welcome Home!");
?>
